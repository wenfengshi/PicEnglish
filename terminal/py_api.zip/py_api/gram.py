import grpc,sys
import grammar_service_pb2

_TIMEOUT_SECONDS = 10

def main(txt):
    channel = grpc.insecure_channel('%s:%d' % ('54.222.198.42', 50054))
    stub = grammar_service_pb2.GrammarServiceStub(channel)
    response = stub.GrammarCorrect(grammar_service_pb2.GrammarCorrectRequest(content = txt, error_type = ""), _TIMEOUT_SECONDS)
    print(response.message)

if __name__ == '__main__':
    if(len(sys.argv)<2):
        exit()
    main(sys.argv[1])
